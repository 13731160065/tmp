function back() {
    selfVC.popVC();
}

function btn() {
	var str = "wzzoch5://test1/test.html";
	var nextVC = selfVC.allocWithClass("WZZOCH5VC");
	selfVC.setObjWithKeyPathValueObj("url", str, nextVC);
	selfVC.pushVC(nextVC);
}
