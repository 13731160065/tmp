$(".btn").click(function(){
//	alert(111)
//  add();
OCH5_pushVCWithUrl("wzzoch5://index.html");
});