$(".btn").click(function(){
                alert(111);
//  add();
//OCH5_pushVCWithUrl("wzzoch5://index.html");
//                var phone = och5_LoginObject.OCH5_getValue_context_value("phone");
//                alert(phone);
});
