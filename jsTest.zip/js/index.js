$(".btn").click(function(){
                var phone = OCH5_getValue_context_value(och5_LoginObject, "phone");
                alert(phone);
});
