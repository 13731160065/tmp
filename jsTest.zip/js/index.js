$(".btn").click(function(){
//                alert(111);
//  add();
//OCH5_pushVCWithUrl("wzzoch5://index.html");
                alert(1);
                alert(och5_JSContext);
                alert(och5_LoginObject);
                var phone = OCH5_getValue_context_value(och5_LoginObject, "phone");
                alert(phone);
});
