$(".btn").click(function(){
//                alert(111);
//  add();
//OCH5_pushVCWithUrl("wzzoch5://index.html");
                alert(och5_JSContext);
//                var phone = OCH5_getValue_context_value(och5_LoginObject, "phone");
//                alert(phone);
});
