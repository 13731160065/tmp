$(".btn").click(function(){
	alert(111)
    add();
});