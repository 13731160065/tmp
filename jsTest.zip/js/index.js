$(".btn").click(function(){
//                alert(111);
//  add();
//OCH5_pushVCWithUrl("wzzoch5://index.html");
                var phone = OCH5_getValue_context_value(och5_LoginObject, "phone");
                alert(phone);
                OCH5_setValue_context_valueName_value(och5_LoginObject, "idnum", "130130199310041010");
});
