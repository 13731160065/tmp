function add(){
    $(".btn").addClass("btn1");
}
function reduce(){
    $(".btn").removeClass("btn1");
}

