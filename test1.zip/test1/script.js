function back() {
    selfVC.navigationController.popViewControllerAnimated(true);
}

function btn() {
    alert("hhhhhhhh");
}
