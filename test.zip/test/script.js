function back() {
    console.log("back")
}

function btn() {
    console.log("btn")
}