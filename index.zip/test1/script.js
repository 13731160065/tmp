function back() {
    OCH5_popViewController();
}

function btn() {
    alert(document.head.innerHTML);
//	var str = "wzzoch5://test2/test2.html";
//	OCH5_pushVCWithUrl(str);
}
