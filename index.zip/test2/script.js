function back() {
    var nav = och5_jsContext.getObjWithKeyPathObj("navigationController", och5_jsContext);
    och5_jsContext.runFuncWithObjFuncNameArg1(nav, "popViewControllerAnimated:", "1");
}

function btn() {
	var str = "wzzoch5://test1/test.html";
   var testModel = och5_jsContext.allocWithClass("WZZTestModel");
   och5_jsContext.setObjWithKeyPathValueObj("name", "小明", testModel);
   och5_jsContext.setObjWithKeyPathValueObj("age", "10", testModel);
   och5_jsContext.setObjWithKeyPathValueObj("height", "170.5", testModel);
   och5_jsContext.setObjWithKeyPathValueObj("isMan", "YES", testModel);
   var argsDic = new Map();
   argsDic["model"] = testModel;
   och5_jsContext.callBackFuncArgsDic("changeInfo", argsDic);
}

function changeInfo() {
   var name = och5_jsContext.getObjWithKeyPathObj("name", och5CallBack_model);
   var age = och5_jsContext.getObjWithKeyPathObj("age", och5CallBack_model);
   var height = och5_jsContext.getObjWithKeyPathObj("height", och5CallBack_model);
   var isMan = och5_jsContext.getObjWithKeyPathObj("isMan", och5CallBack_model);
   document.getElementById('contentDiv').innerHTML = "name:"+name+"\nage:"+age+"\nheight:"+height+"\nisMan:"+isMan;
}

function UrlSearch() {
   var name,value; 
   var str=location.href; //取得整个地址栏
   var num=str.indexOf("?") 
   str=str.substr(num+1); //取得所有参数   stringvar.substr(start [, length ]

   var arr=str.split("&"); //各个参数放到数组里
   var arr2 = new Array();
   for(var i=0;i < arr.length;i++) {
   	num=arr[i].indexOf("="); 
	if (num > 0) {
		name=arr[i].substring(0,num);
		value=arr[i].substr(num+1);
		arr2[name]=value;
	}
   }
   return arr2;
}
